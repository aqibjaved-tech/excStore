<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    // public $newDomainName = 'sundiego';
    // public function setNewDomainName($sdn){
    //     if($sdn != 'sundiego') {
    //         $newDomainName = $sdn;
    //     } else {
    //         $newDomainName = 'sundiego';
    //     }
    //     // $newDomainName = $sdn;
    // }
    // public function getDomainName(){
    //     return $newDomainName;
    // }
}
